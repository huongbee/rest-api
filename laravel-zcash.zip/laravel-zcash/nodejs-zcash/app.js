const express = require('express')
const app = express()
const request = require('request');
const Zcash = require('zcash');

const rpc = new Zcash({
    username: "zcash",
    password: "__password__"
});
 
 
app.get('/', function (req, res) {
  res.send('Hello World')
})
 
app.listen(3000,()=>{
    console.log('connect to port 3000')
})

request('http://www.google.com',  (error, response, body)=> {
//   console.log('error:', error);
//   console.log('statusCode:', response && response.statusCode); 
//   console.log('body:', body); 
});


app.get('/listaddress', (req, res) => {
    rpc.z_listaddresses().then(addresses => {
        res.render('addresses', {
            addresses: addresses
        });
    });
});